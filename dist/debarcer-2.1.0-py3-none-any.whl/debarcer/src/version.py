# -*- coding: utf-8 -*-
"""
Created on Mon Oct 28 14:57:35 2019

@author: RJovelin
"""

# setup and code access debarcer version from this module
__version__ = "2.1.0"
